# SyncedSidebarBg

![SyncedSidebarBg](http://cl.ly/image/3m380Z0J1M03/SyncedSidebarBg.gif)

### Caveats:
- Not working well with multiple windows, sidebar background color changes globally.
