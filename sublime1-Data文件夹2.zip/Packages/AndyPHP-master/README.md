AndyPHP
=======

Alternative PHP Completions

These completions are more up-to date, and include 
more arguments, than the default completions. Many 
extension modules are block-commented out by default: 
uncomment any of these libraries if you wish to use 
them, and block-comment any that you do not require.  
(Ctrl-Shift-/ is the default key-binding to toggle 
comments.)

For some of the completions there are two versions: 
(full) denotes completions with the full argument 
list.

You should move the default PHP.sublime-completions 
file outside your Packages area. This is likely to 
be reinstalled on a future ST update or build - so 
you will need to move this file each time!